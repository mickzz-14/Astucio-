// Minimal, dependency-free MD5 implementation (public-domain algorithm),
// used only for the "Hash MD5" tool. Not intended for cryptographic security.

function rotateLeft(x: number, c: number) {
  return (x << c) | (x >>> (32 - c));
}

function toUnsigned(x: number) {
  return x >>> 0;
}

function addUnsigned(x: number, y: number) {
  return toUnsigned(x + y);
}

function cmn(q: number, a: number, b: number, x: number, s: number, t: number) {
  return addUnsigned(rotateLeft(addUnsigned(addUnsigned(a, q), addUnsigned(x, t)), s), b);
}

function ff(a: number, b: number, c: number, d: number, x: number, s: number, t: number) {
  return cmn((b & c) | (~b & d), a, b, x, s, t);
}
function gg(a: number, b: number, c: number, d: number, x: number, s: number, t: number) {
  return cmn((b & d) | (c & ~d), a, b, x, s, t);
}
function hh(a: number, b: number, c: number, d: number, x: number, s: number, t: number) {
  return cmn(b ^ c ^ d, a, b, x, s, t);
}
function ii(a: number, b: number, c: number, d: number, x: number, s: number, t: number) {
  return cmn(c ^ (b | ~d), a, b, x, s, t);
}

function convertToWordArray(str: string) {
  const bytes: number[] = [];
  for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i));
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 0; i < 8; i++) bytes.push((bitLen >>> (i * 8)) & 0xff);

  const words: number[] = [];
  for (let i = 0; i < bytes.length; i += 4) {
    words.push(bytes[i] | (bytes[i + 1] << 8) | (bytes[i + 2] << 16) | (bytes[i + 3] << 24));
  }
  return words;
}

function wordToHex(word: number) {
  let hex = "";
  for (let i = 0; i < 4; i++) {
    const byte = (word >>> (i * 8)) & 0xff;
    hex += ("0" + byte.toString(16)).slice(-2);
  }
  return hex;
}

export function md5(input: string): string {
  const x = convertToWordArray(unescape(encodeURIComponent(input)));
  let a = 0x67452301,
    b = 0xefcdab89,
    c = 0x98badcfe,
    d = 0x10325476;

  for (let k = 0; k < x.length; k += 16) {
    const [aa, bb, cc, dd] = [a, b, c, d];

    a = ff(a, b, c, d, x[k + 0], 7, -680876936);
    d = ff(d, a, b, c, x[k + 1], 12, -389564586);
    c = ff(c, d, a, b, x[k + 2], 17, 606105819);
    b = ff(b, c, d, a, x[k + 3], 22, -1044525330);
    a = ff(a, b, c, d, x[k + 4], 7, -176418897);
    d = ff(d, a, b, c, x[k + 5], 12, 1200080426);
    c = ff(c, d, a, b, x[k + 6], 17, -1473231341);
    b = ff(b, c, d, a, x[k + 7], 22, -45705983);
    a = ff(a, b, c, d, x[k + 8], 7, 1770035416);
    d = ff(d, a, b, c, x[k + 9], 12, -1958414417);
    c = ff(c, d, a, b, x[k + 10], 17, -42063);
    b = ff(b, c, d, a, x[k + 11], 22, -1990404162);
    a = ff(a, b, c, d, x[k + 12], 7, 1804603682);
    d = ff(d, a, b, c, x[k + 13], 12, -40341101);
    c = ff(c, d, a, b, x[k + 14], 17, -1502002290);
    b = ff(b, c, d, a, x[k + 15], 22, 1236535329);

    a = gg(a, b, c, d, x[k + 1], 5, -165796510);
    d = gg(d, a, b, c, x[k + 6], 9, -1069501632);
    c = gg(c, d, a, b, x[k + 11], 14, 643717713);
    b = gg(b, c, d, a, x[k + 0], 20, -373897302);
    a = gg(a, b, c, d, x[k + 5], 5, -701558691);
    d = gg(d, a, b, c, x[k + 10], 9, 38016083);
    c = gg(c, d, a, b, x[k + 15], 14, -660478335);
    b = gg(b, c, d, a, x[k + 4], 20, -405537848);
    a = gg(a, b, c, d, x[k + 9], 5, 568446438);
    d = gg(d, a, b, c, x[k + 14], 9, -1019803690);
    c = gg(c, d, a, b, x[k + 3], 14, -187363961);
    b = gg(b, c, d, a, x[k + 8], 20, 1163531501);
    a = gg(a, b, c, d, x[k + 13], 5, -1444681467);
    d = gg(d, a, b, c, x[k + 2], 9, -51403784);
    c = gg(c, d, a, b, x[k + 7], 14, 1735328473);
    b = gg(b, c, d, a, x[k + 12], 20, -1926607734);

    a = hh(a, b, c, d, x[k + 5], 4, -378558);
    d = hh(d, a, b, c, x[k + 8], 11, -2022574463);
    c = hh(c, d, a, b, x[k + 11], 16, 1839030562);
    b = hh(b, c, d, a, x[k + 14], 23, -35309556);
    a = hh(a, b, c, d, x[k + 1], 4, -1530992060);
    d = hh(d, a, b, c, x[k + 4], 11, 1272893353);
    c = hh(c, d, a, b, x[k + 7], 16, -155497632);
    b = hh(b, c, d, a, x[k + 10], 23, -1094730640);
    a = hh(a, b, c, d, x[k + 13], 4, 681279174);
    d = hh(d, a, b, c, x[k + 0], 11, -358537222);
    c = hh(c, d, a, b, x[k + 3], 16, -722521979);
    b = hh(b, c, d, a, x[k + 6], 23, 76029189);
    a = hh(a, b, c, d, x[k + 9], 4, -640364487);
    d = hh(d, a, b, c, x[k + 12], 11, -421815835);
    c = hh(c, d, a, b, x[k + 15], 16, 530742520);
    b = hh(b, c, d, a, x[k + 2], 23, -995338651);

    a = ii(a, b, c, d, x[k + 0], 6, -198630844);
    d = ii(d, a, b, c, x[k + 7], 10, 1126891415);
    c = ii(c, d, a, b, x[k + 14], 15, -1416354905);
    b = ii(b, c, d, a, x[k + 5], 21, -57434055);
    a = ii(a, b, c, d, x[k + 12], 6, 1700485571);
    d = ii(d, a, b, c, x[k + 3], 10, -1894986606);
    c = ii(c, d, a, b, x[k + 10], 15, -1051523);
    b = ii(b, c, d, a, x[k + 1], 21, -2054922799);
    a = ii(a, b, c, d, x[k + 8], 6, 1873313359);
    d = ii(d, a, b, c, x[k + 15], 10, -30611744);
    c = ii(c, d, a, b, x[k + 6], 15, -1560198380);
    b = ii(b, c, d, a, x[k + 13], 21, 1309151649);
    a = ii(a, b, c, d, x[k + 4], 6, -145523070);
    d = ii(d, a, b, c, x[k + 11], 10, -1120210379);
    c = ii(c, d, a, b, x[k + 2], 15, 718787259);
    b = ii(b, c, d, a, x[k + 9], 21, -343485551);

    a = addUnsigned(a, aa);
    b = addUnsigned(b, bb);
    c = addUnsigned(c, cc);
    d = addUnsigned(d, dd);
  }

  return wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d);
}
